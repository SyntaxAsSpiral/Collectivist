"""
Collectivist - AI-powered collection curator
Self-contained collection indexing and documentation system
"""

__version__ = "1.0.0"